package com.amdocs.main;

import java.util.*;
import java.io.*;
import java.lang.*;

import com.amdocs.plantnursery.dao.PlantDAO;
import com.amdocs.plantnursery.dao.PlantDAOFunc;
import com.amdocs.plantnursery.exception.plantNotFoundException;
import com.amdocs.plantnursery.pojos.Plant;

public class Main {
	public static void main(String[] args){
		PlantDAO pdao=new PlantDAOFunc();
		Scanner sc=new Scanner(System.in);
		System.out.println("Nursery Plant Management System:\n");
		boolean flag=true;
		do{
			System.out.println("Options:\r\n"+"1. Add new plant\r\n"+"2. Delete plant\r\n"+"3. Update plant cost\r\n"+"4. View all plants\r\n"+"5. Search plants by country of origin\r\n"+"6. Search for outdoor plants that need sunlight\r\n"+"7. Count plants by water supply frequency\r\n"+"8. Exit\r\n");
			System.out.println("Enter option: ");
			int choice=sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Add new plant:");
				System.out.println("Enter plant ID: ");
				int plantID=sc.nextInt();
				System.out.println("Enter plant name: ");
				String plantName=sc.next();
				System.out.println("Enter country of origin: ");
				String originCountryName=sc.next();
				System.out.println("Does the plant require sunlight(true, false): ");
				boolean sunlightRequired=sc.nextBoolean();
				System.out.println("Enter frequency of water supply(daily, alternateDays, weekly): ");
				String waterSupplyFrequency=sc.next();
				System.out.println("Enter type of plant(indoor, outdoor): ");
				String plantType=sc.next();
				System.out.println("Enter cost of plant: ");
				double cost=sc.nextDouble();
				Plant plant=new Plant(plantID, plantName, originCountryName, sunlightRequired, waterSupplyFrequency, plantType, cost);
				pdao.addPlant(plant);
				System.out.println("Plant added.\n");
				break;
				
			case 2:
				System.out.println("Delete plant: ");
				System.out.println("Enter plant ID to delete: ");
				int plantID2=sc.nextInt();
				int flag1=0;
				try{
					flag1=pdao.deletePlant(plantID2);
					if(flag1==0){
						//pdao.deletePlant(plantID2);
						throw new plantNotFoundException("Plant not found.\n");
					}
					else{
						System.out.println("Plant deleted.\n");
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				break;
				
			case 3:
				System.out.println("Update plant cost: ");
				System.out.println("Enter plant ID: ");
				int plantID3=sc.nextInt();
				System.out.println("Enter new cost: ");
				double newCost=sc.nextDouble();
				boolean flag2=false;
				try{
					flag2=pdao.updatePlantCost(plantID3, newCost);
					if(flag2){
						System.out.println("Plant not found.\n");
					}
					else{
						throw new plantNotFoundException("Plant cost updated.\n");
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				break;
				
			case 4: 
				System.out.println("View saved plants: \n");
				try{
					List<Plant> Plants=pdao.showAllPlants();
					if(Plants.size()==0){
						throw new plantNotFoundException("Plants not found.\n");
					}
					else{
						for(Plant plant1:Plants){
							System.out.println(plant1);
						}
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				break;
			case 5:
				System.out.println("Search for plant by country of origin: ");
				String countryName=sc.next();
				try{
					List<Plant> searchList=pdao.searchByOriginCountryName(countryName);
					if(searchList.size()==0){
						
						throw new plantNotFoundException("Plants not found.\n");
					}
					else{
						for(Plant plant2:searchList){
							System.out.println(plant2);
						}	
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				
				break;
			case 6:
				System.out.println("Search for plants that need sunlight: ");
				try{
					List<Plant> searchList1=pdao.searchOutdoorPlantsWithSunlight();
					if(searchList1.size()==0){
						
						throw new plantNotFoundException("Plants not found.\n");
					}
					else{
						for(Plant plant3:searchList1){
							System.out.println(plant3);
						}
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				
				break;
			case 7:
				System.out.println("Search for plant by water supply frequency: ");
				String waterFrequency=sc.next();
				int count=-1;
				try{
					count=pdao.countPlantsByWaterSupplyFrequency(waterFrequency);
					if(count==0){
						throw new plantNotFoundException("Plants not found.\n");
					}
					else{
						System.out.println("Number of plants with "+waterFrequency+" water supply frequency: "+count);
					}
				}
				catch(plantNotFoundException e){
					e.printStackTrace();
				}
				break;
			case 8:
				System.out.println("Exiting.\n");
				flag=false;
				break;
			}
		}
		while(flag==true);
	}
}
