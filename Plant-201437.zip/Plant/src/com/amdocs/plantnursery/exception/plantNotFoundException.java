package com.amdocs.plantnursery.exception;

public class plantNotFoundException extends Exception {
	private String message;
	public plantNotFoundException(){}
	public plantNotFoundException(String message){
		this.message=message;
	}
	@Override
	public String toString() {
		return "plantNotFoundException [message=" + message + "]";
	}
}
