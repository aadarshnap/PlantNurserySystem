package com.amdocs.plantnursery.dao;

import java.util.*;
import java.io.*;
import java.lang.*;

import com.amdocs.plantnursery.exception.plantNotFoundException;
import com.amdocs.plantnursery.pojos.Plant;

public interface PlantDAO {
	int addPlant(com.amdocs.plantnursery.pojos.Plant plant);
	int deletePlant(int plantID) throws plantNotFoundException;
	boolean updatePlantCost(int plantID, double cost) throws plantNotFoundException;
	List<Plant> showAllPlants() throws plantNotFoundException;;
	List<Plant> searchByOriginCountryName(String originCountryName) throws plantNotFoundException;
	List<Plant> searchOutdoorPlantsWithSunlight() throws plantNotFoundException;
	int countPlantsByWaterSupplyFrequency(String waterSupplyFrequency) throws plantNotFoundException;
}
