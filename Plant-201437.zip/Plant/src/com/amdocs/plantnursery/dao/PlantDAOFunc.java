package com.amdocs.plantnursery.dao; 

import java.util.*;
import java.io.*;
import java.lang.*;

import com.amdocs.plantnursery.exception.plantNotFoundException;
import com.amdocs.plantnursery.pojos.Plant;

public class PlantDAOFunc implements PlantDAO{
	List<Plant> Plants=new ArrayList<>();
	
	@Override
	public int addPlant(Plant plant){
		Plants.add(plant);
		return plant.getPlantID();
	}
	
	
	public int deletePlant(int plantID) throws plantNotFoundException{
		for(Plant plant:Plants){
			if(plant.getPlantID()==plantID){
				Plants.remove(plant);
				break;
			}
		}
		return plantID;
	}
	@Override
	public boolean updatePlantCost(int plantID, double cost) throws plantNotFoundException{
		for(Plant plant:Plants){
			if(plant.getPlantID()==plantID){
				plant.setCost(cost);
				return true;
			}
		}
		return false;
	}
	
	@Override
	public List<Plant> showAllPlants(){
		return Plants;
	}
	
	@Override
	public List<Plant> searchByOriginCountryName(String originCountryName) throws plantNotFoundException{
		List<Plant> searchList=new ArrayList<>();
		for(Plant plant:Plants){
			if(plant.getOriginCountryName().equals(originCountryName)){
				System.out.println(plant);
				searchList.add(plant);
			}
		}
		return searchList;
	}
	
	@Override
	public List<Plant> searchOutdoorPlantsWithSunlight() throws plantNotFoundException{
		List<Plant> searchList=new ArrayList<>();
		for(Plant plant:Plants){
			if(plant.isSunlightRequired() && plant.getPlantType().equals("outdoor")){
				System.out.println(plant);
				searchList.add(plant);
			}
		}
		return searchList;
	}
	
	@Override
	public int countPlantsByWaterSupplyFrequency(String waterSupplyFrequency) throws plantNotFoundException{
		int count=0;
		for(Plant plant:Plants){
			if(plant.getWaterSupplyFrequency().equals(waterSupplyFrequency)){
				count++;
			}
		}
		return count;
	}
}
