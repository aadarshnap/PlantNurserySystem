package com.amdocs.plantnursery.pojos;

public class Plant {
	int plantID;
	String plantName;
	String originCountryName;
	boolean sunlightRequired;
	String waterSupplyFrequency;
	String plantType;
	double cost;
	
	public Plant(int id, String name, String origin, boolean sunlight, String water, String type, double cost){
		super();
		this.plantID=id;
		this.plantName=name;
		this.originCountryName=origin;
		this.sunlightRequired=sunlight;
		this.waterSupplyFrequency=water;
		this.plantType=type;
		this.cost=cost;
	}
	
	public String getPlantName() {
		return plantName;
	}

	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	public String getOriginCountryName() {
		return originCountryName;
	}

	public void setOriginCountryName(String originCountryName) {
		this.originCountryName = originCountryName;
	}

	public boolean isSunlightRequired() {
		return sunlightRequired;
	}

	public void setSunlightRequired(boolean sunlightRequired) {
		this.sunlightRequired = sunlightRequired;
	}

	public String getWaterSupplyFrequency() {
		return waterSupplyFrequency;
	}

	public void setWaterSupplyFrequency(String waterSupplyFrequency) {
		this.waterSupplyFrequency = waterSupplyFrequency;
	}

	public String getPlantType() {
		return plantType;
	}

	public void setPlantType(String plantType) {
		this.plantType = plantType;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public void setPlantID(int plantID) {
		this.plantID = plantID;
	}

	public int getPlantID(){
		return plantID;
	}

	@Override
	public String toString() {
		return "Plant [plantID=" + plantID + ", plantName=" + plantName
				+ ", originCountryName=" + originCountryName
				+ ", sunlightRequired=" + sunlightRequired
				+ ", waterSupplyFrequency=" + waterSupplyFrequency
				+ ", plantType=" + plantType + ", cost=" + cost + "]";
	}
}
